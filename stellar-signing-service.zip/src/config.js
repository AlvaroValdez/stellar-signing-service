module.exports = {
  NETWORK: process.env.NETWORK || 'testnet'
};